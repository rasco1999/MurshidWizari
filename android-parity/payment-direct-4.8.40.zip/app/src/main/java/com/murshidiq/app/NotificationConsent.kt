package com.murshidiq.app

import android.content.Context

/** Optional notification consent. It is never inferred from launching the app. */
object NotificationConsent {
    const val policyVersion="2026-10-19"
    private fun prefs(context: Context)=context.getSharedPreferences("notification_consent",Context.MODE_PRIVATE)
    fun pushConsent(context: Context,userId: Int)=userId>0 && prefs(context).getInt("push_consent_user",0)==userId
    fun consentPush(context: Context,userId: Int) { require(userId>0);prefs(context).edit().putInt("push_consent_user",userId).commit() }
    fun revokePush(context: Context) { prefs(context).edit().remove("push_consent_user").commit() }
}
