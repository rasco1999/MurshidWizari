package com.murshidiq.app
import org.junit.Assert.*
import org.junit.Test
class FamilyPrivacyTest {
    @Test fun minimumAgeAndUnknownAreRejected() {
        for (band in listOf(-1,0,1,6,100)) assertFalse(FamilyPrivacy.eligible(band))
        for (band in 2..5) assertTrue(FamilyPrivacy.eligible(band))
    }
    @Test fun minorsAreNotMistakenForAdults() {
        for (band in 2..4) assertTrue(FamilyPrivacy.minor(band))
        assertFalse(FamilyPrivacy.minor(5))
    }
}
