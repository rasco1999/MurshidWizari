package com.murshidiq.app
import org.junit.Assert.*
import org.junit.Test
class FamilyAccessRulesTest {
    private val token = "a".repeat(64)
    @Test fun offlineWindowClosesAfter72HoursAndOnClockRollback() {
        assertTrue(FamilyAccessRules.offlineAllowed(token, "approved", 999999, 100, 259300))
        assertFalse(FamilyAccessRules.offlineAllowed(token, "approved", 999999, 100, 259301))
        assertFalse(FamilyAccessRules.offlineAllowed(token, "approved", 999999, 100, 99))
    }
    @Test fun backgroundPushDoesNotRequireOpeningAppEvery72Hours() {
        assertFalse(FamilyAccessRules.offlineAllowed(token, "approved", 999999, 100, 300000))
        assertTrue(FamilyAccessRules.pushAllowed(token, "approved", 999999, true, 300000))
        assertFalse(FamilyAccessRules.pushAllowed(token, "approved", 999999, false, 300000))
    }
    @Test fun RevokedExpiredOrMissingGrantsNeverAllowAccess() {
        for (status in listOf("pending", "revoked", "rejected", "expired")) {
            assertFalse(FamilyAccessRules.pushAllowed(token, status, 999999, true, 100))
            assertFalse(FamilyAccessRules.offlineAllowed(token, status, 999999, 100, 100))
        }
        assertFalse(FamilyAccessRules.pushAllowed("", "approved", 999999, true, 100))
        assertFalse(FamilyAccessRules.pushAllowed(token, "approved", 100, true, 100))
    }
}
