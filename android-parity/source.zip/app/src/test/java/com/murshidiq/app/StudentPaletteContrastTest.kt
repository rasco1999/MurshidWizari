package com.murshidiq.app

import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.pow

class StudentPaletteContrastTest {
    @Test fun primaryActionsHaveReadableWhiteLabelsInAllThemes() {
        for (id in listOf(AppearanceRules.ROYAL, AppearanceRules.VIOLET, AppearanceRules.AURORA)) {
            val rgb = StudentPaletteRules.palette(id).primary
            fun linear(channel: Int): Double {
                val s = channel / 255.0
                return if (s <= .04045) s / 12.92 else ((s + .055) / 1.055).pow(2.4)
            }
            val luminance = .2126 * linear(rgb shr 16 and 255) + .7152 * linear(rgb shr 8 and 255) + .0722 * linear(rgb and 255)
            assertTrue("White button text in $id", 1.05 / (luminance + .05) >= 4.5)
        }
    }
}
