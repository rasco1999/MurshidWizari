package com.murshidiq.app

import org.junit.Assert.*
import org.junit.Test

class ScreenNavigationTest {
    @Test fun nestedDetailsReturnToTheirCallerAfterRedrawAndTabChanges() {
        val state = ScreenNavigation()
        state.arrive("account", 0)
        state.arrive("coach", 410)
        state.arrive("coach", 0) // async redraw must preserve its caller
        state.arrive("review", 180)
        assertEquals("coach", state.back("review"))
        assertEquals(180, state.arrive("coach", 0))
        state.arrive("coach_question", 180)
        assertEquals("coach", state.back("coach_question"))
        state.arrive("coach", 0)
        assertEquals("account", state.back("coach"))
        assertEquals(410, state.arrive("account", 0))
        state.arrive("home", 410)
        state.arrive("notifications", 280)
        assertEquals("home", state.back("notifications"))
        assertEquals(280, state.arrive("home", 0))
    }

    @Test fun logoutDiscardsPrivateNavigationAndOffsets() {
        val state = ScreenNavigation()
        state.arrive("account", 0); state.arrive("support", 700)
        state.clear()
        assertEquals(0, state.arrive("account", 0))
        assertNull(state.back("account"))
    }
}
