package com.murshidiq.app

object FamilyAccessRules {
    private fun validGrant(token: String, status: String, expires: Long, now: Long) =
        token.matches(Regex("[a-f0-9]{64}")) && status == "approved" && expires > now
    fun offlineAllowed(token: String, status: String, expires: Long, checked: Long, now: Long) =
        validGrant(token, status, expires, now) && now - checked in 0..259200
    fun pushAllowed(token: String, status: String, expires: Long, optedIn: Boolean, now: Long) =
        validGrant(token, status, expires, now) && optedIn
}
