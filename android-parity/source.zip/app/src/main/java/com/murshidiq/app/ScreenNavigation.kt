package com.murshidiq.app

/** Keeps detail Back actions anchored to the page that actually opened them. */
internal class ScreenNavigation {
    private var rendered = ""
    private var returningTo = ""
    private val parents = mutableMapOf<String, String>()
    private val offsets = mutableMapOf<String, Int>()
    val details = setOf("coach", "notifications", "favorites", "review", "study_plan",
        "attempt_history", "focus", "practice_builder", "question_proposal", "question_submissions",
        "stories", "support", "account_privacy", "performance_diagnostics")

    fun arrive(screen: String, oldScrollY: Int): Int {
        if (rendered != screen) {
            if (rendered.isNotBlank()) offsets[rendered] = oldScrollY.coerceAtLeast(0)
            if (screen in details && screen != returningTo && rendered.isNotBlank()) parents[screen] = rendered
            rendered = screen
            returningTo = ""
        }
        return offsets[screen] ?: 0
    }

    fun back(screen: String): String? = if (screen in details) {
        (parents[screen] ?: "home").also { returningTo = it }
    } else null

    fun clear() { rendered = ""; returningTo = ""; parents.clear(); offsets.clear() }
}
