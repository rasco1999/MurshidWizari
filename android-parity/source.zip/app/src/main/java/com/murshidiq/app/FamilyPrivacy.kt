package com.murshidiq.app

import android.content.Context

/** Age is self-declared. This is not verification of a parent's identity or legal consent. */
object FamilyPrivacy {
    const val policyVersion = "2026-10-18"
    val bands = listOf("اختر الفئة العمرية", "أقل من ١٠ سنوات", "١٠–١٢ سنة", "١٣–١٥ سنة", "١٦–١٧ سنة", "١٨ سنة فأكثر")
    fun eligible(band: Int) = band in 2..5
    fun minor(band: Int) = band in 2..4
    private fun prefs(context: Context) = context.getSharedPreferences("family_privacy", Context.MODE_PRIVATE)
    fun accepted(context: Context) = prefs(context).getString("policy_version", "") == policyVersion && eligible(prefs(context).getInt("age_band", 0))
    fun accept(context: Context, band: Int) {
        require(eligible(band))
        prefs(context).edit().putInt("age_band", band).putString("policy_version", policyVersion).commit()
    }
    fun blockUnderage(context: Context) { prefs(context).edit().putLong("underage_until", System.currentTimeMillis() + 86400000L).commit() }
    fun blocked(context: Context) = prefs(context).getLong("underage_until", 0L) > System.currentTimeMillis()
    fun ageBand(context: Context) = prefs(context).getInt("age_band", 0)
    fun pushConsent(context: Context, userId: Int) = accepted(context) && FamilyAccess.pushAllowed(context) && userId > 0 && prefs(context).getInt("push_consent_user", 0) == userId
    fun consentPush(context: Context, userId: Int) { require(userId > 0); prefs(context).edit().putInt("push_consent_user", userId).commit() }
    fun revokePush(context: Context) { prefs(context).edit().remove("push_consent_user").commit() }
}
