package com.murshidiq.app

import android.app.Activity
import com.android.billingclient.api.*

/** Prepaid subscriptions: prices and eligible offers always come from Play. */
class PlaySubscriptionStore(
    private val activity: Activity,
    private val changed: () -> Unit,
    private val purchased: (Purchase) -> Unit,
    private val notice: (String) -> Unit
) {
    data class Plan(val details: ProductDetails, val offerToken: String,
                    val title: String, val price: String)
    var plans: List<Plan> = emptyList(); private set
    var loading = false; private set
    var purchaseNeedsVerification = false; private set
    fun confirmVerification() { purchaseNeedsVerification = false; changed() }
    private val waiting = mutableListOf<() -> Unit>()
    private var connecting = false
    private var closed = false
    private val client: BillingClient = BillingClient.newBuilder(activity)
        .setListener { result, purchases ->
            activity.runOnUiThread {
                if (closed || activity.isFinishing || activity.isDestroyed) return@runOnUiThread
                when (result.responseCode) {
                    BillingClient.BillingResponseCode.OK -> purchases.orEmpty().forEach(::process)
                    BillingClient.BillingResponseCode.USER_CANCELED -> notice("تم إلغاء عملية الشراء؛ لم يُفعّل اشتراك جديد.")
                    BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> restore()
                    else -> notice("تعذر إكمال الشراء من Google Play. حاول مجددًا.")
                }
            }
        }
        .enablePendingPurchases(PendingPurchasesParams.newBuilder()
            .enableOneTimeProducts().enablePrepaidPlans().build())
        .enableAutoServiceReconnection()
        .build()

    private fun ready(action: () -> Unit) {
        if (closed) return
        if (client.isReady) { action(); return }
        waiting.add(action)
        if (connecting) return
        connecting = true
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                activity.runOnUiThread {
                    connecting = false
                    if (closed) return@runOnUiThread
                    val actions = waiting.toList(); waiting.clear()
                    if (result.responseCode == BillingClient.BillingResponseCode.OK) actions.forEach { it() }
                    else { loading = false; changed(); notice("خدمة Google Play غير متاحة. تحقق من المتجر والاتصال ثم أعد المحاولة.") }
                }
            }
            override fun onBillingServiceDisconnected() { connecting = false }
        })
    }

    fun load() {
        if (loading || closed) return
        loading = true
        ready {
            val products = listOf("murshid_month1", "murshid_month3").map {
                QueryProductDetailsParams.Product.newBuilder().setProductId(it)
                    .setProductType(BillingClient.ProductType.SUBS).build()
            }
            client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder()
                .setProductList(products).build()) { result, data ->
                activity.runOnUiThread {
                    if (closed) return@runOnUiThread
                    loading = false
                    plans = if (result.responseCode == BillingClient.BillingResponseCode.OK)
                        data.productDetailsList.mapNotNull { details ->
                            val expected = if (details.productId == "murshid_month1") "prepaid-month1" else "prepaid-month3"
                            val offer = details.subscriptionOfferDetails?.firstOrNull {
                                it.basePlanId == expected && it.offerId == null &&
                                it.pricingPhases.pricingPhaseList.size == 1 &&
                                it.pricingPhases.pricingPhaseList[0].recurrenceMode == ProductDetails.RecurrenceMode.NON_RECURRING
                            } ?: return@mapNotNull null
                            Plan(details, offer.offerToken,
                                if (details.productId == "murshid_month1") "شهر واحد" else "٣ أشهر",
                                offer.pricingPhases.pricingPhaseList[0].formattedPrice)
                        }.sortedBy { it.details.productId } else emptyList()
                    changed()
                }
            }
        }
    }

    fun buy(plan: Plan, accountId: String) {
        if (accountId.isBlank()) { notice("تعذر التحقق من حسابك. حدّث حالة الاشتراك أولًا."); return }
        ready {
            val item = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(plan.details).setOfferToken(plan.offerToken).build()
            val result = client.launchBillingFlow(activity, BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(listOf(item)).setObfuscatedAccountId(accountId).build())
            if (result.responseCode != BillingClient.BillingResponseCode.OK)
                notice("تعذر فتح نافذة الشراء. حدّث الباقات ثم حاول مجددًا.")
        }
    }

    fun restore(silent: Boolean = false): Unit = ready {
        client.queryPurchasesAsync(QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.SUBS).build()) { result, purchases ->
            activity.runOnUiThread {
                if (closed) return@runOnUiThread
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    if (purchases.isEmpty()) { purchaseNeedsVerification = false; changed() }
                    purchases.forEach(::process)
                    if (purchases.isEmpty() && !silent) notice("لا توجد مشتريات Google Play قابلة للاستعادة لهذا الحساب في المتجر.")
                } else if (!silent) notice("تعذر استعادة المشتريات الآن. حاول مجددًا.")
            }
        }
    }

    private fun process(purchase: Purchase) {
        if (purchase.products.none { it in setOf("murshid_month1", "murshid_month3") }) return
        when (purchase.purchaseState) {
            Purchase.PurchaseState.PURCHASED -> { purchaseNeedsVerification = true; purchased(purchase) }
            Purchase.PurchaseState.PENDING -> { purchaseNeedsVerification = true; notice("عملية الشراء قيد الانتظار. سيُفعّل الاشتراك بعد اكتمال الدفع والتحقق منه.") }
        }
    }

    fun close() { closed = true; waiting.clear(); client.endConnection() }
}
