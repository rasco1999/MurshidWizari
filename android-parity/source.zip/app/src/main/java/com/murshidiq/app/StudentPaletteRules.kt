package com.murshidiq.app

/** ThemeV34.swift colors, kept independent of Android for contrast checks. */
internal object StudentPaletteRules {
    data class Palette(val navy: Int, val primary: Int, val accent: Int, val secondary: Int)
    fun palette(id: String): Palette = when (id) {
        AppearanceRules.AURORA -> Palette(0x062734, 0x097275, 0x5EE8C7, 0x38ABE8)
        AppearanceRules.VIOLET -> Palette(0x20153D, 0x6C48A6, 0xFCA3D1, 0xBA6EE0)
        else -> Palette(0x0B1F33, 0x2D6CDF, 0xF5B83D, 0x1747AD)
    }
}
