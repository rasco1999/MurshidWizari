package com.murshidiq.app

import android.content.Context
import org.json.JSONObject

/** Server receipt encrypted at rest; no parental identity documents are stored on-device. */
object FamilyAccess {
    const val clientPolicy = "families-20261017-v2"
    private fun storage(context: Context) = SecureCoachStorage(context.getSharedPreferences("family_access_secure", Context.MODE_PRIVATE))
    private fun state(context: Context): JSONObject = runCatching { JSONObject(storage(context).read(1) ?: "{}") }.getOrDefault(JSONObject())
    fun token(context: Context): String = state(context).optString("token")
    fun needsNewRequest(context: Context) = token(context).isBlank() || state(context).optString("status") in setOf("expired", "rejected", "revoked", "none")
    fun reference(context: Context): String = state(context).optString("reference")
    fun ready(context: Context): Boolean {
        val s = state(context)
        val now = System.currentTimeMillis() / 1000
        return FamilyAccessRules.offlineAllowed(s.optString("token"), s.optString("status"),
            s.optLong("expires_at_unix"), s.optLong("checked_at"), now)
    }
    fun pushAllowed(context: Context): Boolean {
        val s = state(context)
        // The server rechecks guardian permission before every push. Do not impose
        // the offline-study refresh window on background notification reception.
        return FamilyAccessRules.pushAllowed(s.optString("token"), s.optString("status"),
            s.optLong("expires_at_unix"), s.optBoolean("push_allowed"), System.currentTimeMillis() / 1000)
    }
    fun update(context: Context, response: JSONObject): Boolean {
        if (!response.optBoolean("ok")) return false
        val old = state(context)
        for (name in listOf("token", "reference", "status", "push_allowed", "expires_at_unix"))
            if (response.has(name)) old.put(name, response.get(name))
        old.put("checked_at", System.currentTimeMillis() / 1000)
        return storage(context).write(1, old.toString())
    }
    fun restrict(context: Context) {
        val s = state(context).put("status", "review_required").put("push_allowed", false)
        storage(context).write(1, s.toString())
    }
}
