#!/usr/bin/env bash
set -u
qa_output="$1"
qa_suite="$2"
qa_api="$3"
qa_failed=0
run_check() {
  python3 "android-native/scripts/$1" --output "$qa_output/$2" "${@:3}"
  qa_result=$?
  if [ "$qa_result" -ne 0 ]; then
    echo "FAILED $1 (exit $qa_result)"
    qa_failed=1
  fi
}
if [ "$qa_suite" = 'pages' ]; then
  run_check screen_parity_qa.py pages
  run_check phone_verification_qa.py verification
  if [ "$qa_api" = '35' ]; then run_check compact_layout_qa.py layout --smoke; fi
else
  run_check specialized_exam_qa.py specialized
  run_check matching_qa.py matching
  run_check offline_exam_qa.py offline
fi
exit "$qa_failed"
