package com.murshidiq.app

import android.content.Context
import android.graphics.Typeface
import android.widget.TextView

/** Script detection remains JVM-testable, but Tajawal shapes both Arabic and Latin.
 * Splitting the same line across fonts caused visibly inconsistent Arabic metrics.
 */
internal object MurshidTextScript {
    private val westernRuns = Regex("[A-Za-z0-9]+(?:[._:/-][A-Za-z0-9]+)*")

    fun containsArabic(value: String): Boolean =
        value.any { Character.UnicodeScript.of(it.code) == Character.UnicodeScript.ARABIC }

    fun latinRuns(value: String): List<IntRange> =
        westernRuns.findAll(value).map { it.range.first until (it.range.last + 1) }.toList()
}

/** Shared, compact typography scale (sp) with readable captions and clear headings.
 * No scaling of large figures or accessibility settings is suppressed.
 */
internal object MurshidTypeScale {
    fun sizeSp(requested: Float): Float = when {
        requested <= 10f -> 11f             // bottom navigation and small status captions
        requested < 12f -> 12f
        requested >= 24f && requested < 27f -> 24f // title width on narrow screens
        else -> requested
    }
}

/** Bundled Google Fonts Tajawal, licensed under SIL Open Font License 1.1.
 * This SINGLE family is used for Arabic, English, numbers, static labels
 * and dynamic EditText content. No OEM/system font substitution is needed.
 */
internal class MurshidTypography(context: Context) {
    // Separate files preserve the same real weights on API 26 as on newer phones.
    private val regular by lazy { context.resources.getFont(R.font.tajawal_regular) }
    private val medium by lazy { context.resources.getFont(R.font.tajawal_medium) }
    private val bold by lazy { context.resources.getFont(R.font.tajawal_bold) }

    fun typeface(value: String = "", bold: Boolean = false): Typeface =
        if (bold) this.bold else regular

    fun medium(): Typeface = medium
    fun strong(): Typeface = bold

    fun apply(label: TextView, value: String, bold: Boolean = false) {
        label.typeface = if (bold) this.bold else regular
        label.text = value
        // Keep room for Arabic dots, vowel marks and mixed Arabic/Latin content.
        label.includeFontPadding = true
    }
}
