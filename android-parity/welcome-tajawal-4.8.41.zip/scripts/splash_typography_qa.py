"""Exercise the delivered preview's animation and compact Tajawal layouts."""
import argparse
import hashlib
import json
import re
import time
from pathlib import Path
import anonymous_emulator_qa as ui


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    out = parser.parse_args().output
    out.mkdir(parents=True, exist_ok=True)
    ui.PACKAGE = 'com.murshidiq.app.preview49825'
    apk = Path(__file__).resolve().parents[1] / 'app/build/outputs/apk/preview/app-preview.apk'
    ui.adb('install', '-r', str(apk))
    ui.adb('shell', 'pm', 'clear', ui.PACKAGE)
    ui.adb('shell', 'wm', 'size', '393x852')
    ui.adb('shell', 'wm', 'density', '160')
    ui.adb('shell', 'settings', 'put', 'system', 'font_scale', '1.0')
    for setting in ('animator_duration_scale', 'transition_animation_scale', 'window_animation_scale'):
        ui.adb('shell', 'settings', 'put', 'global', setting, '1')
    try:
        ui.adb('shell', 'am', 'force-stop', ui.PACKAGE)
        ui.adb('logcat', '-c')
        ui.adb('shell', 'am', 'start', '-n', f'{ui.PACKAGE}/{ui.MAIN_ACTIVITY}')
        time.sleep(.45)
        first = ui.adb('exec-out', 'screencap', '-p')
        (out / '01-cold-animation-early.png').write_bytes(first)
        time.sleep(.7)
        second = ui.adb('exec-out', 'screencap', '-p')
        (out / '02-cold-animation-reveal.png').write_bytes(second)
        assert hashlib.sha256(first).digest() != hashlib.sha256(second).digest(), 'Launch artwork did not animate'
        ui.wait_for('تعلّم بتركيز. تقدّم بثقة.')
        logs = ui.adb('logcat', '-d', '-v', 'epoch', '-s', 'MurshidWelcome:I', '*:S').decode(errors='replace')
        (out / 'welcome.log').write_text(logs)
        def event(name):
            match = re.search(r'(?m)^\s*(\d+\.\d+)\s+.*' + re.escape(name), logs)
            assert match, (name, logs)
            return float(match.group(1))
        duration = event('cold-welcome-completed') - event('cold-welcome-started')
        assert 2.9 <= duration < 4.5, ('Welcome must finish independently of network', duration)
        ui.capture(out, '03-guest-after-animation', 'تعلّم بتركيز. تقدّم بثقة.')
        ui.adb('shell', 'input', 'keyevent', 'KEYCODE_HOME')
        time.sleep(5)
        ui.adb('shell', 'am', 'start', '-n', f'{ui.PACKAGE}/{ui.MAIN_ACTIVITY}')
        time.sleep(.5)
        (out / '04-resume-animation.png').write_bytes(ui.adb('exec-out', 'screencap', '-p'))
        time.sleep(3)
        ui.wait_for('تعلّم بتركيز. تقدّم بثقة.')
        logs = ui.adb('logcat', '-d', '-v', 'brief', '-s', 'MurshidWelcome:I', '*:S')
        assert b'background-replay-started' in logs, 'Launcher return skipped the welcome'
        for width, height, scale in ((320, 640, 1.0), (360, 720, 1.3)):
            ui.adb('shell', 'settings', 'put', 'system', 'font_scale', str(scale))
            ui.adb('shell', 'wm', 'size', f'{width}x{height}')
            ui.launch_native()
            ui.enter_login(width, height)
            marker = 'سجّل الدخول وواصل دراستك من حيث توقفت'
            ui.wait_for(marker)
            ui.capture(out, f'05-login-{width}-font{scale}', marker)
            root, _ = ui.ui_tree()
            for text in ('الشروط والأحكام', 'سياسة الخصوصية'):
                node = ui.find(root, text)
                assert node is not None, text
                left, top, right, bottom = map(int, ui.BOUNDS.fullmatch(node.attrib['bounds']).groups())
                assert 0 <= left < right <= width and 0 <= top < bottom <= height, node.attrib
            # Ensure the long Arabic primary action can still be reached and tapped.
            ui.reveal('إنشاء حساب طالب جديد', width, height)
            ui.tap_visible('إنشاء حساب طالب جديد', width, height)
            ui.wait_for('بيانات الطالب')
            ui.capture(out, f'06-register-{width}-font{scale}', 'بيانات الطالب')
        runtime = ui.adb('logcat', '-d', '-v', 'brief', 'AndroidRuntime:E', '*:S')
        assert b'FATAL EXCEPTION' not in runtime, runtime
        (out / 'results.json').write_text(json.dumps({
            'passed': True, 'cold_animation_seconds': duration, 'frames_change': True,
            'resume_animation': True, 'compact_widths': [320, 360], 'large_font_scale': 1.3,
            'legal_footer_visible': True,
        }, indent=2))
        print('PASS animated cold/resume launch, three-second duration, 320/360dp and enlarged font', flush=True)
    finally:
        ui.adb('shell', 'wm', 'size', '393x852')
        ui.adb('shell', 'settings', 'put', 'system', 'font_scale', '1.0')
        (out / 'runtime.log').write_bytes(ui.adb('logcat', '-d', '-v', 'threadtime', 'AndroidRuntime:E', '*:S'))


if __name__ == '__main__':
    main()
